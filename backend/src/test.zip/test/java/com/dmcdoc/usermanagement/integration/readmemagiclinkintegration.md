# 🧩 User Management API — Magic Link & OAuth2 Tests

## 🏗️ Pré-requis
- Docker & Docker Compose
- Maven 3.9+
- JDK 21+

---

## 🚀 Lancement de l’environnement

```bash
docker compose up -d
