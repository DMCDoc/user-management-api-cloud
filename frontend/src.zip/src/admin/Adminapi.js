import api from "../api/api";

export async function fetchUsers(page = 0, size = 20, search = "") {
  const response = await api.get("/admin/users", {
    params: { page, size, search }
  });
  return response.data;
}

export async function updateUser(id, data) {
  const response = await api.put(`/admin/users/${id}`, data);
  return response.data;
}

export async function updateUserRole(id, roles) {
  const response = await api.put(`/api/admin/users/${id}/roles`, roles);
  return response.data;
}

export async function deleteUser(id) {
  return api.delete(`/api/admin/users/${id}`);
}

export async function blockUser(id) {
  return api.put(`/api/admin/users/${id}/block`);
}

export async function unblockUser(id) {
  return api.put(`/api/admin/users/${id}/unblock`);
}

export async function adminResetPassword(id) {
  const res = await api.post(`/admin/users/${id}/reset-password`);
  return res.data;
}

export async function fetchUsers(page = 0, size = 20, search = "") {
  return api.get("/api/admin/users", {
    params: { page, size, search }
  }).then(r => r.data);
}

export async function fetchStats() {
  const res = await api.get("/api/admin/stats");
  return res.data;
}
export async function fetchLogs() {
  const res = await api.get("/admin/logs");
  return res.data;
}
export async function patchUser(userId, body) {
  const res = await api.patch(`/admin/users/${userId}`, body);
  return res.data;
}

export async function blockUser(userId) { return api.put(`/admin/users/${userId}/block`); }
export async function unblockUser(userId) { return api.put(`/admin/users/${userId}/unblock`); }
export async function adminResetPassword(userId) { const r = await api.post(`/admin/users/${userId}/reset-password`); return r.data; }
export async function deleteUser(userId) { return api.delete(`/admin/users/${userId}`); }
export async function fetchRoles() { const r = await api.get("/admin/roles"); return r.data; }
