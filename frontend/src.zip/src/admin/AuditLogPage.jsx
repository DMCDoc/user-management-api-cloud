import { useEffect, useState } from "react";
import { DataGrid } from "@mui/x-data-grid";
import { fetchAuditLog } from "./api";

export default function AuditLogPage() {
  const [rows, setRows] = useState([]);

  useEffect(() => {
    fetchAuditLog().then(setRows);
  }, []);

  const columns = [
    { field: "timestamp", headerName: "Date", flex: 1 },
    { field: "adminEmail", headerName: "Admin", flex: 1 },
    { field: "action", headerName: "Action", flex: 1 },
    { field: "userId", headerName: "User ID", width: 120 }
  ];

  return <DataGrid rows={rows} columns={columns} autoHeight />;
}
