import AdminLayout from "./AdminLayout";
import { DataGrid } from "@mui/x-data-grid";
import { fetchLogs } from "./api";

export default function LogsPage(){
  const [rows, setRows] = useState([]);
  useEffect(()=> { fetchLogs().then(setRows); }, []);
  const columns = [{ field:'timestamp', headerName:'Time', flex:1 }, { field:'adminEmail', headerName:'Admin', flex:1 }, { field:'action', headerName:'Action', flex:2 }, { field:'userId', headerName:'UserId', width:240 }];
  return <AdminLayout><div style={{height:600}}><DataGrid rows={rows} columns={columns} /></div></AdminLayout>;
}
