import { useEffect, useState } from "react";
import { fetchUsers, fetchRoles, patchUser, resetPassword } from "./api";
import EditUserModal from "./EditUserModal";

export default function UserList(){
  const [q, setQ] = useState("");
  const [page, setPage] = useState(0);
  const [size] = useState(10);
  const [data, setData] = useState(null);
  const [roles, setRoles] = useState([]);
  const [editing, setEditing] = useState(null);

  const load = () => fetchUsers({q, page, size}).then(setData).catch(console.error);
  useEffect(()=> { fetchRoles().then(setRoles); load(); }, [page]);

  const onSearch = ()=> { setPage(0); load(); };

  if(!data) return <div>Loading...</div>;
  return (
    <div>
      <div className="flex gap-2 mb-4">
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search email or username" className="border p-2 rounded"/>
        <button onClick={onSearch} className="px-3 py-2 bg-blue-600 text-white rounded">Search</button>
      </div>

      <table className="min-w-full bg-white">
        <thead>/* header */</thead>
        <tbody>
          {data.content.map(u => (
            <tr key={u.id}>
              <td>{u.email}</td>
              <td>{u.username}</td>
              <td>{u.roles.join(", ")}</td>
              <td>
                <button onClick={()=>setEditing(u)} className="mr-2">Edit</button>
                <button onClick={async()=>{ const res = await resetPassword(u.id); alert("Temp: "+res.tempPassword); }}>Reset PW</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-4 flex gap-2">
        <button disabled={page===0} onClick={()=>{ setPage(p=>Math.max(0,p-1)); load(); }}>Prev</button>
        <span>Page {data.number+1} / {data.totalPages}</span>
        <button disabled={data.number+1>=data.totalPages} onClick={()=>{ setPage(p=>p+1); load(); }}>Next</button>
      </div>

      {editing && <EditUserModal user={editing} roles={roles} onClose={()=>{ setEditing(null); load(); }} onSave={async (body)=>{ await patchUser(editing.id, body); setEditing(null); load(); }} />}
    </div>
  );
}
