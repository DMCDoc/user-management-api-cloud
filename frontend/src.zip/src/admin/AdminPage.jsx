import { useEffect, useState } from "react";
import { Box, Grid, Card, CardContent, Typography } from "@mui/material";
import UserTable from "./UserTable";
import { fetchUsers } from "./api";
import StatsChart from "./StatsChart";

export default function AdminPage() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalAdmins: 0,
    totalBlocked: 0
  });

  async function loadStats() {
    const data = await fetchUsers(0, 10000);
    setStats({
      totalUsers: data.content.length,
      totalAdmins: data.content.filter(u => u.roles.includes("ADMIN")).length,
      totalBlocked: data.content.filter(u => u.blocked === true).length,
    });
  }

  useEffect(() => {
    loadStats();
  }, []);

  return (
    <Box p={3}>
      <Typography variant="h4" mb={3}>Admin Dashboard</Typography>

      <Grid container spacing={2} mb={3}>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="h6">Total Users</Typography>
              <Typography variant="h4">{stats.totalUsers}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="h6">Admins</Typography>
              <Typography variant="h4">{stats.totalAdmins}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="h6">Blocked Accounts</Typography>
              <Typography variant="h4">{stats.totalBlocked}</Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

       {/* Nouvelle section pour le graphique */}
      <Grid container spacing={2} mb={3}>
        <Grid item xs={12} md={6}>
          <StatsChart
            title="User Distribution"
            data={[
              { name: "Admins", value: stats.totalAdmins },
              { name: "Regular Users", value: stats.totalUsers - stats.totalAdmins }
            ]}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <StatsChart
            title="Account Status"
            data={[
              { name: "Blocked", value: stats.totalBlocked },
              { name: "Active", value: stats.totalUsers - stats.totalBlocked }
            ]}
          />
        </Grid>
      </Grid>

      <UserTable users={users} /> {/* Passez les users au tableau si nécessaire */}
      
    </Box>
  );
}
