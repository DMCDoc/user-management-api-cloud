import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";
import { Box, Button, TextField } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import EditUserDialog from "./EditUserDialog";
import { fetchUsers, deleteUser, adminResetPassword, blockUser, unblockUser } from "./api";

export default function UsersPage(){
  const [page, setPage] = useState(0);
  const [size] = useState(20);
  const [search, setSearch] = useState("");
  const [rows, setRows] = useState([]);
  const [pageInfo, setPageInfo] = useState({ totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(false);
  const [editUser, setEditUser] = useState(null);

  const load = async () => {
    setLoading(true);
    const data = await fetchUsers({ page, size, search });
    setRows(data.content);
    setPageInfo({ totalPages: data.totalPages, totalElements: data.totalElements });
    setLoading(false);
  };

  useEffect(()=> { load(); }, [page]);

  const columns = [
    { field: "id", headerName: "ID", width: 200 },
    { field: "email", headerName: "Email", flex: 1 },
    { field: "username", headerName: "Username", width: 180 },
    { field: "roles", headerName: "Roles", width: 220, valueGetter: (p)=> p.row.roles?.join(", ") },
    { field: "enabled", headerName: "Enabled", width: 120, type: "boolean" },
    {
      field: "actions",
      headerName: "Actions",
      width: 300,
      renderCell: (params) => (
        <>
          <Button size="small" onClick={()=> setEditUser(params.row)}>Edit</Button>
          <Button size="small" color="error" onClick={()=> deleteUser(params.row.id).then(load)}>Delete</Button>
          <Button size="small" onClick={async ()=> { const r = await adminResetPassword(params.row.id); alert("New password: " + r.tempPassword || r.newPassword); }}>Reset PW</Button>
          {params.row.enabled ? (
            <Button size="small" color="warning" onClick={()=> blockUser(params.row.id).then(load)}>Block</Button>
          ) : (
            <Button size="small" color="success" onClick={()=> unblockUser(params.row.id).then(load)}>Unblock</Button>
          )}
        </>
      )
    }
  ];

  return (
    <AdminLayout>
      <Box mb={2} display="flex" gap={2}>
        <TextField label="Search" size="small" value={search} onChange={(e)=>setSearch(e.target.value)} onKeyDown={(e)=> e.key==="Enter" && (setPage(0), load())}/>
        <Button variant="contained" onClick={()=> { setPage(0); load(); }}>Search</Button>
      </Box>

      <div style={{ height: 600 }}>
        <DataGrid
          rows={rows}
          columns={columns}
          pageSizeOptions={[size]}
          paginationMode="server"
          rowCount={pageInfo.totalElements}
          paginationModel={{ page, pageSize: size }}
          onPaginationModelChange={(m) => setPage(m.page)}
          loading={loading}
        />
      </div>

      {editUser && <EditUserDialog user={editUser} onClose={() => setEditUser(null)} onSaved={load} />}
    </AdminLayout>
  );
}
