import { useEffect, useState } from "react";
import { fetchStats } from "./api";
import { fetchUsers, updateUser, updateUserRole, deleteUser } from "./admin/AdminApi";

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);

  useEffect(()=> { fetchStats().then(setStats).catch(console.error); }, []);

  if(!stats) return <div>Loading...</div>;

  return (
    <div className="grid grid-cols-3 gap-4">
      <div className="p-4 bg-white rounded shadow">
        <h3 className="text-sm text-gray-500">Total users</h3>
        <p className="text-2xl font-bold">{stats.totalUsers}</p>
      </div>
      <div className="p-4 bg-white rounded shadow">
        <h3 className="text-sm text-gray-500">Admins</h3>
        <p className="text-2xl font-bold">{stats.admins}</p>
      </div>
      <div className="p-4 bg-white rounded shadow">
        <h3 className="text-sm text-gray-500">Disabled</h3>
        <p className="text-2xl font-bold">{stats.disabled}</p>
      </div>
    </div>
  );
}
