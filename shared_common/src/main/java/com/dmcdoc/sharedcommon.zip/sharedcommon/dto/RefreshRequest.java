package com.example.usermanagement.api.dto;

import lombok.Data;

@Data
public class RefreshRequest {
    private String refreshToken;
}
